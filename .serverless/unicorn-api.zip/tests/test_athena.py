import boto3
from moto import mock_athena


def test_query_athena():
    pass


def test_bad_query_athena():
    pass
